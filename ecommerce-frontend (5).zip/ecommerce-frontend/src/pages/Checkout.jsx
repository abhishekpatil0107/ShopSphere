import { useCart } from "../context/CartContext";
import { useUser } from "../context/useUser";
import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { api } from "../api/client";

export default function Checkout() {
  const { cart } = useCart();
  const { user } = useUser();
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  // Redirect if not logged in
  useEffect(() => {
    if (!user) navigate("/login");
  }, [user, navigate]);

  if (!user) return null;

  const total = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const invoiceNumber = Math.floor(Math.random() * 1000000);

  const handlePayment = async () => {
    if (cart.length === 0) return;

    try {
      setLoading(true);

      // 1️⃣ Create order on backend
      const rpOrder = await api(`/api/checkout/${user.id}`, {
        method: "POST",
        body: JSON.stringify({ items: cart }),
      });

      if (!rpOrder || !rpOrder.success || !rpOrder.data) {
        throw new Error("Order creation failed");
      }

      const orderData = rpOrder.data;

      // 2️⃣ Setup Razorpay options
      const options = {
        key: "rzp_test_oFSgfunyJ7jrsA",
        amount: orderData.amount, // in paise
        currency: orderData.currency,
        name: "AP Mart",
        description: "Order Payment",
        order_id: orderData.id, // Razorpay order ID
        handler: async function (response) {
          try {
            // 3️⃣ Verify payment with backend
            await api("/api/payment/verify", {
              method: "POST",
              body: JSON.stringify({
                orderId: orderData.localOrderId,
                razorpayPaymentId: response.razorpay_payment_id,
                razorpayOrderId: response.razorpay_order_id,
                razorpaySignature: response.razorpay_signature,
              }),
            });

            // 4️⃣ Navigate to PaymentSuccess page
            navigate("/payment-success", {
              state: {
                order: {
                  id: orderData.localOrderId,
                  amount: orderData.amount / 100,
                  status: "PAID",
                },
              },
            });
          } catch (err) {
            console.error(err);
            alert("Payment verification failed");
          } finally {
            setLoading(false);
          }
        },
        prefill: {
          name: user.name,
          email: user.email,
          contact: "9999999999",
        },
        theme: { color: "#3399cc" },
      };

      const rzp = new window.Razorpay(options);
      rzp.on("payment.failed", function (response) {
        alert("Payment failed: " + response.error.description);
        setLoading(false);
      });

      rzp.open();
    } catch (err) {
      console.error(err);
      alert(err.message || "Payment failed");
      setLoading(false);
    }
  };

  return (
    <div className="p-6 max-w-5xl mx-auto bg-gray-50 min-h-screen">
      {/* Invoice Header */}
      <div className="bg-white p-6 rounded-lg shadow mb-6">
        <h1 className="text-3xl font-bold">AP Mart</h1>
        <p className="text-gray-600">Invoice #: {invoiceNumber}</p>
        <p className="text-gray-600">Date: {new Date().toLocaleDateString()}</p>
      </div>

      {/* Items Table */}
      <div className="bg-white rounded-lg shadow overflow-x-auto">
        <table className="w-full text-left border-collapse">
          <thead className="bg-gray-200">
            <tr>
              <th className="p-3 border">Product Name</th>
              <th className="p-3 border">Quantity</th>
              <th className="p-3 border">Price</th>
              <th className="p-3 border">Total</th>
            </tr>
          </thead>
          <tbody>
            {cart.length === 0 ? (
              <tr>
                <td colSpan="4" className="p-3 text-center text-gray-500">
                  No items in cart
                </td>
              </tr>
            ) : (
              cart.map((item) => (
                <tr key={item.id} className="border-b hover:bg-gray-50">
                  <td className="p-3">{item.name}</td>
                  <td className="p-3 border">{item.quantity}</td>
                  <td className="p-3 border">₹{item.price}</td>
                  <td className="p-3 border font-bold">₹{item.price * item.quantity}</td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* Total Section */}
      <div className="mt-6 bg-white p-6 rounded-lg shadow flex flex-col items-end">
        <h2 className="text-xl font-semibold mb-4">Total: ₹{total.toFixed(2)}</h2>
        <button
          onClick={handlePayment}
          disabled={loading || cart.length === 0}
          className="px-6 py-2 bg-blue-600 text-white rounded-lg disabled:opacity-50"
        >
          {loading ? "Processing..." : "Pay Now"}
        </button>
      </div>
    </div>
  );
}
