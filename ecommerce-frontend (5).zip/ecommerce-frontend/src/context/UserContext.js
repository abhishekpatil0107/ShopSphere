import { createContext } from "react";

// ✅ Create UserContext
export const UserContext = createContext(null);
