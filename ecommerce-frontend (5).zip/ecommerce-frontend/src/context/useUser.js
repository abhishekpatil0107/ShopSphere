import { useContext } from "react";
import { UserContext } from "./UserContext";

// ✅ Custom hook for consuming UserContext
export function useUser() {
  return useContext(UserContext);
}
