// src/pages/Checkout.jsx
import { useCart } from "../context/CartContext";

export default function Checkout() {
  const { cart } = useCart();

  const total = cart.reduce(
    (sum, item) => sum + item.price * item.quantity,
    0
  );

  const invoiceNumber = Math.floor(Math.random() * 1000000);

  return (
    <div className="p-6 max-w-5xl mx-auto bg-gray-50 min-h-screen">
      {/* Invoice Header */}
      <div className="bg-white p-6 rounded-lg shadow mb-6">
        <h1 className="text-3xl font-bold">MyStore</h1>
        <p className="text-gray-600">Invoice #: {invoiceNumber}</p>
        <p className="text-gray-600">Date: {new Date().toLocaleDateString()}</p>
      </div>

      {/* Items Table */}
      <div className="bg-white rounded-lg shadow overflow-x-auto">
        <table className="w-full text-left border-collapse">
          <thead className="bg-gray-200">
            <tr>
              <th className="p-3 border">Product Name</th>
              <th className="p-3 border">Quantity</th>
              <th className="p-3 border">Price</th>
              <th className="p-3 border">Total</th>
            </tr>
          </thead>
          <tbody>
            {cart.length === 0 ? (
              <tr>
                <td colSpan="4" className="p-3 text-center text-gray-500">
                  No items in cart
                </td>
              </tr>
            ) : (
              cart.map((item) => (
                <tr key={item.id} className="border-b hover:bg-gray-50">
                  <td className="p-3">{item.name}</td>
                  <td className="p-3 border">{item.quantity}</td>       
                  <td className="p-3 border">₹{item.price}</td>
                  <td className="p-3 border font-bold">₹{item.price * item.quantity}</td>

                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* Total Section */}
      <div className="mt-6 bg-white p-6 rounded-lg shadow flex flex-col items-end">
        <h2 className="text-xl font-semibold mb-4">Total: ₹{total.toFixed(2)}</h2>
        <button className="px-6 py-2 bg-blue-600 text-white rounded-lg">
          Pay Now
        </button>
      </div>
    </div>
  );
}
