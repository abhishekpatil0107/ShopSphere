import { createContext } from "react";

// Just create context here, no JSX
export const CartContext = createContext();
