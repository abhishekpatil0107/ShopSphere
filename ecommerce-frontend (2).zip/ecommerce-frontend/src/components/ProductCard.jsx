import { useContext } from "react";
import { CartContext } from "../context/CartContext";

export default function ProductCard({ product }) {
  const { addToCart } = useContext(CartContext);

  return (
    <div className="bg-white rounded-xl shadow-md p-4 flex flex-col h-[380px] overflow-hidden">
      {/* Fixed-size image box */}
      <div className="w-full flex justify-center items-center">
        <img
          src={product.image}
          alt={product.name}
          className="w-[180px] h-[180px] object-contain"
        />
      </div>

      {/* Centered name (fixed height to keep cards even) */}
      <h2 className="mt-3 text-center text-base font-semibold text-gray-800 leading-tight h-[44px] overflow-hidden">
        {product.name}
      </h2>

      {/* Centered price */}
      <p className="mt-1 text-center text-lg font-bold text-gray-900">
        ₹{product.price}
      </p>

      {/* Button pinned to bottom */}
      <button
        onClick={() => addToCart(product)}
        className="mt-auto w-full bg-yellow-500 hover:bg-yellow-600 text-black font-semibold py-2 rounded-lg transition"
      >
        Add to Cart
      </button>
    </div>
  );
}
