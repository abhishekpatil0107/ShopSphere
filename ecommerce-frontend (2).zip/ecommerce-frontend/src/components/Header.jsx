import { Link } from "react-router-dom";
import { useContext } from "react";
import { CartContext } from "../context/CartContext";
import CartContent from "./CartContent";

export default function Header() {
  const { cartCount, showCart, setShowCart } = useContext(CartContext);

  return (
    <header className="bg-gradient-to-r from-purple-600 via-pink-500 to-red-500 text-white p-4 shadow-lg sticky top-0 z-50">
      <div className="flex justify-between items-center max-w-6xl mx-auto relative">
        <Link
          to="/"
          className="text-3xl font-bold hover:text-yellow-300 transition duration-500 transform hover:scale-110"
        >
          Ecommerce
        </Link>

        <nav className="flex gap-6 items-center">
          <button
            onClick={() => setShowCart(!showCart)}
            className="relative hover:text-yellow-300 transition duration-300 transform hover:scale-105"
          >
            Cart
            <span className="ml-1 bg-red-500 text-white text-xs font-bold px-2 py-0.5 rounded-full">
              {cartCount}
            </span>
          </button>

          <Link
            to="/checkout"
            className="bg-white text-purple-600 px-4 py-2 rounded hover:bg-purple-600 hover:text-white transition duration-300 font-semibold"
          >
            Checkout
          </Link>
        </nav>

        {showCart && (
          <div className="absolute right-0 top-full mt-2 w-80 bg-white text-black rounded shadow-lg z-50">
            <CartContent />
          </div>
        )}
      </div>
    </header>
  );
}
