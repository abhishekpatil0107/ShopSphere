import { useContext } from "react";
import { CartContext } from "../context/CartContext";
import { payWithRazorpay } from "../services/razorpay";

export default function Checkout() {
  const { cart } = useContext(CartContext);
  const total = cart.reduce((sum, item) => sum + item.price * item.qty, 0);

  const handlePayment = () => {
    const order = { id: "order_123456", amount: total * 100 };
    payWithRazorpay(order);
  };

  if (cart.length === 0)
    return <p className="p-6 text-center text-purple-700 font-semibold">Your cart is empty. Add products first!</p>;

  return (
    <div className="p-6 max-w-md mx-auto bg-purple-50 rounded-lg shadow-lg">
      <h1 className="text-3xl font-bold mb-6 text-purple-700">Checkout</h1>
      <div className="mb-4 space-y-2">
        {cart.map(item => (
          <div key={item.id} className="flex justify-between p-2 rounded hover:bg-purple-100 transition duration-300">
            <span>{item.name} x {item.qty}</span>
            <span>₹{item.price * item.qty}</span>
          </div>
        ))}
      </div>
      <p className="text-xl font-bold mb-6 text-purple-700">Total: ₹{total}</p>
      <button
        onClick={handlePayment}
        className="bg-gradient-to-r from-purple-600 via-pink-500 to-red-500 text-white px-6 py-2 rounded hover:scale-105 transition transform duration-300 font-semibold w-full"
      >
        Pay Now
      </button>
    </div>
  );
}
