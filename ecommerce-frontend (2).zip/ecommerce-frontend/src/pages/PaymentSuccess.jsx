import { Link } from "react-router-dom";

export default function PaymentSuccess() {
  return (
    <div className="p-6 text-center flex flex-col items-center justify-center">
      <h1 className="text-4xl font-bold mb-4 text-purple-700 animate-bounce">Payment Successful!</h1>
      <p className="mb-6 text-gray-700">Thank you for your purchase. Your order will be processed shortly.</p>
      <Link
        to="/"
        className="bg-gradient-to-r from-purple-600 via-pink-500 to-red-500 text-white px-6 py-2 rounded hover:scale-105 transition transform duration-300 font-semibold"
      >
        Continue Shopping
      </Link>
    </div>
  );
}
