// src/main/java/com/ecommerce/security/JwtUtil.java
package com.ecommerce.security;

import io.jsonwebtoken.*;
import io.jsonwebtoken.security.Keys;
import org.springframework.stereotype.Component;
import java.security.Key;
import java.util.Date;

@Component
public class JwtUtil {
  // For demo/dev. In prod, load from env/Secret Manager
  private static final String SECRET = "replace-with-a-very-long-secret-key-at-least-256-bits";
  private static final long EXP_MS = 1000L * 60 * 60 * 24 * 7; // 7 days

  private final Key key = Keys.hmacShaKeyFor(SECRET.getBytes());

  public String generate(Long userId, String email) {
    return Jwts.builder()
      .setSubject(String.valueOf(userId))
      .claim("email", email)
      .setIssuedAt(new Date())
      .setExpiration(new Date(System.currentTimeMillis() + EXP_MS))
      .signWith(key, SignatureAlgorithm.HS256)
      .compact();
  }

  public Jws<Claims> parse(String token) {
    return Jwts.parserBuilder().setSigningKey(key).build().parseClaimsJws(token);
  }

  public Long userId(String token) {
    return Long.valueOf(parse(token).getBody().getSubject());
  }

  public String email(String token) {
    return (String) parse(token).getBody().get("email");
  }
}
