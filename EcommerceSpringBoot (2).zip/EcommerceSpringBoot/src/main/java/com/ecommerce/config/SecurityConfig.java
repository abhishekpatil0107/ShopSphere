// src/main/java/com/ecommerce/config/SecurityConfig.java
package com.ecommerce.config;

import com.ecommerce.security.JwtUtil;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.util.StringUtils;

import java.io.IOException;
import java.util.Collections;

@Configuration
public class SecurityConfig {

  private final JwtUtil jwt;

  public SecurityConfig(JwtUtil jwt) {
    this.jwt = jwt;
  }

  @Bean
  public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
    http.csrf(csrf -> csrf.disable())
        .cors(Customizer.withDefaults())
        .authorizeHttpRequests(auth -> auth
          .requestMatchers("/api/auth/**").permitAll()
          .requestMatchers(HttpMethod.GET, "/api/products/**").permitAll()
          // everything else requires login
          .anyRequest().authenticated()
        )
        .addFilterBefore(new JwtFilter(jwt), UsernamePasswordAuthenticationFilter.class);

    return http.build();
  }

  static class JwtFilter extends org.springframework.web.filter.OncePerRequestFilter {
    private final JwtUtil jwt;
    JwtFilter(JwtUtil jwt){ this.jwt = jwt; }

    @Override
    protected void doFilterInternal(HttpServletRequest req, HttpServletResponse res, FilterChain chain)
        throws ServletException, IOException {

      String auth = req.getHeader("Authorization");
      if (StringUtils.hasText(auth) && auth.startsWith("Bearer ")) {
        String token = auth.substring(7);
        try {
          Long userId = jwt.userId(token);
          // Minimal auth object – we only need userId in SecurityContext
          UserDetails principal = org.springframework.security.core.userdetails.User
              .withUsername(String.valueOf(userId))
              .password("") // not used
              .authorities(Collections.emptyList())
              .build();
          UsernamePasswordAuthenticationToken at =
              new UsernamePasswordAuthenticationToken(principal, null, principal.getAuthorities());
          SecurityContextHolder.getContext().setAuthentication(at);
          // also expose userId for controllers if needed
          req.setAttribute("auth.userId", userId);
        } catch (Exception ignored) {}
      }
      chain.doFilter(req, res);
    }
  }
}
