package com.ecommerce.controller;

import com.ecommerce.dto.ApiResponse;
import com.ecommerce.entity.Order;
import com.ecommerce.repository.OrderRepository;
import com.ecommerce.service.CartService;
import com.ecommerce.service.CheckoutService;
import com.ecommerce.service.PaymentService;
import org.json.JSONObject;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/checkout")
@CrossOrigin(origins = "http://localhost:3000")
public class CheckoutController {
  private final CartService cartService;
  private final CheckoutService checkoutService;
  private final PaymentService paymentService;
  private final OrderRepository orderRepo;

  public CheckoutController(CartService cartService, CheckoutService checkoutService, PaymentService paymentService, OrderRepository orderRepo) {
    this.cartService = cartService;
    this.checkoutService = checkoutService;
    this.paymentService = paymentService;
    this.orderRepo = orderRepo;
  }

  @PostMapping("/create-order")
  public ApiResponse<JSONObject> createOrder(@RequestHeader("X-USER-ID") Long uid) {
    try {
      int amountRupees = (int) Math.round(cartService.cartTotal(uid)); // rupees
      String rpOrder = paymentService.createRazorpayOrder(amountRupees); // converts to paise
      JSONObject rp = new JSONObject(rpOrder); // contains id, amount, currency
      Order order = checkoutService.createOrderFromCart(uid, rp.getString("id"));
      rp.put("localOrderId", order.getId());
      return new ApiResponse<>(true, rp, "Razorpay order created");
    } catch (Exception e) {
      return new ApiResponse<>(false, null, "Failed to create order: " + e.getMessage());
    }
  }

  @GetMapping("/my-orders")
  public List<Order> myOrders(@RequestHeader("X-USER-ID") Long uid){
    return orderRepo.findByUserId(uid);
  }
}
