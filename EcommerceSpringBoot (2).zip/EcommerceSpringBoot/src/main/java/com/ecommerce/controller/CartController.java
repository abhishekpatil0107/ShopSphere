package com.ecommerce.controller;

import com.ecommerce.dto.AddToCartRequest;
import com.ecommerce.dto.UpdateCartRequest;
import com.ecommerce.entity.CartItem;
import com.ecommerce.dto.ApiResponse;
import com.ecommerce.service.CartService;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/cart")
@CrossOrigin(origins = "http://localhost:3000")
public class CartController {
  private final CartService cartService;

  public CartController(CartService cartService) {
    this.cartService = cartService;
  }

  @GetMapping
  public List<CartItem> getCart(@RequestHeader("X-USER-ID") Long uid) {
    return cartService.getCart(uid);
  }

  @PostMapping
  public CartItem add(@RequestHeader("X-USER-ID") Long uid, @Valid @RequestBody AddToCartRequest req){
    return cartService.addToCart(uid, req);
  }

  @PutMapping
  public CartItem update(@Valid @RequestBody UpdateCartRequest req){
    return cartService.updateQuantity(req.getCartItemId(), req.getQuantity());
  }

  @DeleteMapping("/{cartItemId}")
  public ApiResponse<Void> remove(@PathVariable Long cartItemId){
    cartService.removeItem(cartItemId);
    return new ApiResponse<>(true, null, "Removed");
  }

  @DeleteMapping("/clear")
  public ApiResponse<Void> clear(@RequestHeader("X-USER-ID") Long uid){
    cartService.clearCart(uid);
    return new ApiResponse<>(true, null, "Cleared");
  }
}
