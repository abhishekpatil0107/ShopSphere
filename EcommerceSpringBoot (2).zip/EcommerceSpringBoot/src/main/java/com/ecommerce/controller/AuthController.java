// src/main/java/com/ecommerce/controller/AuthController.java
package com.ecommerce.controller;

import com.ecommerce.dto.ApiResponse;
import com.ecommerce.dto.AuthRequest;
import com.ecommerce.dto.AuthResponse;
import com.ecommerce.entity.User;
import com.ecommerce.repository.UserRepository;
import com.ecommerce.security.JwtUtil;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

@RestController
@RequestMapping("/api/auth")
@CrossOrigin(origins = "http://localhost:3000", allowCredentials = "true")
public class AuthController {

  private final UserRepository users;
  private final PasswordEncoder encoder;
  private final JwtUtil jwt;

  public AuthController(UserRepository users, PasswordEncoder encoder, JwtUtil jwt) {
    this.users = users; this.encoder = encoder; this.jwt = jwt;
  }

  @PostMapping("/register")
  public ApiResponse<AuthResponse> register(@RequestBody AuthRequest req) {
    users.findByEmail(req.getEmail()).ifPresent(u -> {
      throw new ResponseStatusException(HttpStatus.CONFLICT, "Email already registered");
    });

    User u = new User();
    u.setName(req.getEmail().split("@")[0]);
    u.setEmail(req.getEmail());
    u.setPasswordHash(encoder.encode(req.getPassword()));
    u = users.save(u);

    String token = jwt.generate(u.getId(), u.getEmail());
    return new ApiResponse<>(true, new AuthResponse(token, u.getId(), u.getName(), u.getEmail()), "Registered");
  }

  @PostMapping("/login")
  public ApiResponse<AuthResponse> login(@RequestBody AuthRequest req) {
    User u = users.findByEmail(req.getEmail())
        .orElseThrow(() -> new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Invalid credentials"));
    if (!encoder.matches(req.getPassword(), u.getPasswordHash())) {
      throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Invalid credentials");
    }
    String token = jwt.generate(u.getId(), u.getEmail());
    return new ApiResponse<>(true, new AuthResponse(token, u.getId(), u.getName(), u.getEmail()), "Logged in");
  }

  @GetMapping("/me")
  public ApiResponse<AuthResponse> me(@RequestHeader("Authorization") String auth) {
    if (auth == null || !auth.startsWith("Bearer ")) {
      throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Missing token");
    }
    String token = auth.substring(7);
    Long uid = jwt.userId(token);
    User u = users.findById(uid).orElseThrow(() -> new ResponseStatusException(HttpStatus.UNAUTHORIZED, "User not found"));
    return new ApiResponse<>(true, new AuthResponse(token, u.getId(), u.getName(), u.getEmail()), "OK");
  }
}
