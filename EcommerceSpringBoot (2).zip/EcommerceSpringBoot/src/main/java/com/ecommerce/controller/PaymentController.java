package com.ecommerce.controller;

import com.ecommerce.dto.ApiResponse;
import com.ecommerce.dto.PaymentVerificationRequest;
import com.ecommerce.entity.Order;
import com.ecommerce.service.CheckoutService;
import com.ecommerce.service.PaymentService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/payment")
@CrossOrigin(origins = "http://localhost:3000")
public class PaymentController {

    private final PaymentService paymentService;
    private final CheckoutService checkoutService;

    public PaymentController(PaymentService paymentService,
                             CheckoutService checkoutService) {
        this.paymentService = paymentService;
        this.checkoutService = checkoutService;
    }

    // Step 1: Create Order from Cart
    @PostMapping("/create/{userId}")
    public ApiResponse<Order> createOrder(@PathVariable Long userId) {
        try {
            Order order = checkoutService.createOrderFromCart(userId);
            return new ApiResponse<>(true, order, "Order created successfully");
        } catch (RuntimeException e) {
            return new ApiResponse<>(false, null, e.getMessage());
        }
    }

    // Step 2: Verify Payment
    @PostMapping("/verify")
    public ApiResponse<String> verify(@RequestBody PaymentVerificationRequest body) {
        boolean ok = paymentService.verifySignature(
                body.getRazorpayOrderId(),
                body.getRazorpayPaymentId(),
                body.getRazorpaySignature()
        );

        if (!ok) return new ApiResponse<>(false, null, "Signature mismatch");

        checkoutService.markPaid(body.getOrderId(), body.getRazorpayPaymentId());
        return new ApiResponse<>(true, "PAID", "Payment verified & order updated");
    }
}
