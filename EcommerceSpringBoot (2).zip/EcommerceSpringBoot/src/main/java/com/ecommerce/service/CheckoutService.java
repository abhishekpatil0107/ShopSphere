package com.ecommerce.service;

import com.ecommerce.entity.CartItem;
import com.ecommerce.entity.Order;
import com.ecommerce.entity.OrderItem;
import com.ecommerce.entity.Product;
import com.ecommerce.entity.User;
import com.ecommerce.repository.CartItemRepository;
import com.ecommerce.repository.OrderItemRepository;
import com.ecommerce.repository.OrderRepository;
import com.ecommerce.repository.ProductRepository;
import com.ecommerce.repository.UserRepository;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.util.ArrayList;
import java.util.List;

@Service
public class CheckoutService {

  private final CartItemRepository cartRepo;
  private final OrderRepository orderRepo;
  private final OrderItemRepository orderItemRepo;
  private final UserRepository userRepo;
  private final ProductRepository productRepo;

  public CheckoutService(CartItemRepository cartRepo,
                         OrderRepository orderRepo,
                         OrderItemRepository orderItemRepo,
                         UserRepository userRepo,
                         ProductRepository productRepo) {
    this.cartRepo = cartRepo;
    this.orderRepo = orderRepo;
    this.orderItemRepo = orderItemRepo;
    this.userRepo = userRepo;
    this.productRepo = productRepo;
  }

  /**
   * Overload used by PaymentController:
   * Creates an order from cart WITHOUT a Razorpay order id.
   */
  @Transactional
  public Order createOrderFromCart(Long userId) {
    return createOrderFromCart(userId, null);
  }

  /**
   * Used by CheckoutController:
   * Creates an order from cart and stores Razorpay order id if provided.
   */
  @Transactional
  public Order createOrderFromCart(Long userId, String razorpayOrderId) {
    User user = userRepo.findById(userId)
        .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "User not found"));

    List<CartItem> cart = cartRepo.findByUserId(userId);
    if (cart.isEmpty()) {
      throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Cart is empty");
    }

    // Validate stock first
    for (CartItem ci : cart) {
      Product prod = ci.getProduct();
      if (ci.getQuantity() > prod.getStock()) {
        throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
            "Not enough stock for product: " + prod.getName());
      }
    }

    // Create order shell
    Order order = new Order();
    order.setUser(user);
    order.setStatus(Order.Status.CREATED);
    order.setRazorpayOrderId(razorpayOrderId);

    // Persist now so child items get a valid FK (optional but safe)
    order = orderRepo.save(order);

    double total = 0.0;
    List<OrderItem> itemsToSave = new ArrayList<>();

    for (CartItem ci : cart) {
      Product p = ci.getProduct();

      OrderItem oi = new OrderItem();
      oi.setOrder(order);
      oi.setProduct(p);
      oi.setQuantity(ci.getQuantity());
      // Store unit price; total uses unit * qty
      oi.setPrice(p.getPrice());
      total += oi.getPrice() * oi.getQuantity();
      itemsToSave.add(oi);

      // Reduce stock
      p.setStock(p.getStock() - ci.getQuantity());
      productRepo.save(p);
    }

    order.setTotalAmount(total);
    orderRepo.save(order);           // update order totals
    orderItemRepo.saveAll(itemsToSave);

    // Clear cart for this user
    cartRepo.deleteByUserId(userId);

    return order;
  }

  /**
   * Marks an order as PAID and stores the Razorpay payment id.
   */
  @Transactional
  public Order markPaid(Long orderId, String razorpayPaymentId) {
    Order order = orderRepo.findById(orderId)
        .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Order not found"));

    if (order.getStatus() == Order.Status.PAID) {
      return order; // idempotent
    }

    order.setStatus(Order.Status.PAID);
    order.setRazorpayPaymentId(razorpayPaymentId);
    return orderRepo.save(order);
  }
}
