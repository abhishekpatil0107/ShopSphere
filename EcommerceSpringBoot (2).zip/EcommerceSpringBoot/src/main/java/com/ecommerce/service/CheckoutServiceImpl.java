package com.ecommerce.service;

import com.ecommerce.entity.CartItem;
import com.ecommerce.entity.Order;
import com.ecommerce.entity.OrderItem;
import com.ecommerce.entity.Product;
import com.ecommerce.entity.User;
import com.ecommerce.repository.CartItemRepository;
import com.ecommerce.repository.OrderRepository;
import com.ecommerce.repository.UserRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class CheckoutServiceImpl {

    private final CartItemRepository cartItemRepo;
    private final OrderRepository orderRepo;
    private final UserRepository userRepo;

    public CheckoutServiceImpl(CartItemRepository cartItemRepo, 
                               OrderRepository orderRepo,
                               UserRepository userRepo) {
        this.cartItemRepo = cartItemRepo;
        this.orderRepo = orderRepo;
        this.userRepo = userRepo;
    }

    // For CheckoutController
    @Transactional
    public Order createOrderFromCart(Long userId, String razorpayOrderId) {
        return buildAndSaveOrder(userId, razorpayOrderId, null);
    }

    // For PaymentController
    @Transactional
    public Order createOrderFromCart(Long userId) {
        return buildAndSaveOrder(userId, null, null);
    }

    // When payment succeeds
    @Transactional
    public void markPaid(Long orderId, String razorpayPaymentId) {
        Order order = orderRepo.findById(orderId)
                .orElseThrow(() -> new RuntimeException("Order not found: " + orderId));
        order.setStatus(Order.Status.PAID);   // ✅ use enum, not string
        order.setRazorpayPaymentId(razorpayPaymentId);
        orderRepo.save(order);
    }

    // Helper: reuse order creation logic
    private Order buildAndSaveOrder(Long userId, String razorpayOrderId, String razorpayPaymentId) {
        List<CartItem> items = cartItemRepo.findByUserId(userId);
        if (items.isEmpty()) {
            throw new RuntimeException("Cart is empty for user: " + userId);
        }

        User user = userRepo.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found: " + userId));

        Order order = new Order();
        order.setUser(user);                       // ✅ set User entity instead of userId
        order.setRazorpayOrderId(razorpayOrderId);
        order.setRazorpayPaymentId(razorpayPaymentId);
        order.setStatus(Order.Status.CREATED);     // ✅ enum

        double total = 0;
        for (CartItem ci : items) {
            Product product = ci.getProduct();

            OrderItem oi = new OrderItem();
            oi.setOrder(order);
            oi.setProduct(product);               // ✅ use Product entity instead of productId
            oi.setQuantity(ci.getQuantity());
            oi.setPrice(product.getPrice());

            total += product.getPrice() * ci.getQuantity();
            order.getItems().add(oi);
        }

        order.setTotalAmount(total);

        // Save order and clear cart
        Order saved = orderRepo.save(order);
        cartItemRepo.deleteByUserId(userId);
        return saved;
    }
}
