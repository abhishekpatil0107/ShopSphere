package com.ecommerce;

import com.ecommerce.entity.Product;
import com.ecommerce.entity.User;
import com.ecommerce.repository.ProductRepository;
import com.ecommerce.repository.UserRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class EcommerceSpringBootApplication {
  public static void main(String[] args) {
    SpringApplication.run(EcommerceSpringBootApplication.class, args);
  }

  @Bean
  CommandLineRunner seed(UserRepository userRepo, ProductRepository productRepo) {
    return args -> {
      if (userRepo.count() == 0) {
        userRepo.save(new User(null, "Demo User", "demo@example.com"));
      }
      if (productRepo.count() == 0) {
        productRepo.save(new Product(null, "Headphones", "Wireless headphones", 1999.0, 50, null));
        productRepo.save(new Product(null, "Keyboard", "Mechanical keyboard", 2999.0, 30, null));
        productRepo.save(new Product(null, "Mouse", "Gaming mouse", 1499.0, 40, null));
      }
    };
  }
}
