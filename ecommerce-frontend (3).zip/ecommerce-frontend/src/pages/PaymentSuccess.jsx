import { useEffect, useState } from "react";
import { Link, useLocation } from "react-router-dom";
import Confetti from "react-confetti";

export default function PaymentSuccess() {
  const location = useLocation();
  const { orderId, amount } = location.state || {}; // passed from checkout

  const [windowSize, setWindowSize] = useState({
    width: window.innerWidth,
    height: window.innerHeight,
  });

  // Resize confetti on window change
  useEffect(() => {
    const handleResize = () =>
      setWindowSize({ width: window.innerWidth, height: window.innerHeight });
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  return (
    <div className="p-6 text-center flex flex-col items-center justify-center relative min-h-screen bg-purple-50">
      {/* 🎉 Confetti Effect */}
      <Confetti width={windowSize.width} height={windowSize.height} recycle={false} />

      <h1 className="text-4xl font-bold mb-4 text-purple-700 animate-bounce">
        Payment Successful!
      </h1>
      <p className="mb-2 text-gray-700">
        Thank you for your purchase. Your order will be processed shortly.
      </p>
      {orderId && (
        <p className="mb-2 text-lg font-semibold text-green-600">
          Order ID: {orderId}
        </p>
      )}
      {amount && (
        <p className="mb-6 text-gray-800">
          Paid: ₹{(amount / 100).toFixed(2)}
        </p>
      )}
      <Link
        to="/"
        className="bg-gradient-to-r from-purple-600 via-pink-500 to-red-500 text-white px-6 py-2 rounded hover:scale-105 transition transform duration-300 font-semibold"
      >
        Continue Shopping
      </Link>
    </div>
  );
}
