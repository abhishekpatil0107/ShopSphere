// src/components/Header.jsx
import { Link } from "react-router-dom";
import { useContext } from "react";
import { CartContext } from "../context/CartContext";

export default function Header() {
  const { cart } = useContext(CartContext);

  return (
    <header className="bg-blue-700 text-white p-4 shadow-md sticky top-0 z-50">
      <div className="container mx-auto flex justify-between items-center">
        {/* Logo */}
        <Link to="/" className="text-2xl font-bold tracking-wide">
          AP Mart
        </Link>

        {/* Nav Links */}
        <nav className="flex gap-6 items-center">
          <Link to="/" className="hover:underline">Home</Link>
          <Link to="/cart" className="hover:underline">
            Cart ({cart.length})
          </Link>
          <Link to="/checkout" className="hover:underline">Checkout</Link>
        </nav>
      </div>
    </header>
  );
}
