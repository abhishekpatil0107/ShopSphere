package com.ecommerce.controller;

import com.ecommerce.dto.ApiResponse;
import com.ecommerce.dto.PaymentVerificationRequest;
import com.ecommerce.entity.Order;
import com.ecommerce.repository.OrderRepository;
import com.ecommerce.service.CheckoutService;
import com.ecommerce.service.PaymentService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/payment")
@CrossOrigin(origins = "http://localhost:3000")
public class PaymentController {
  private final PaymentService paymentService;
  private final CheckoutService checkoutService;
  private final OrderRepository orderRepo;

  public PaymentController(PaymentService paymentService, CheckoutService checkoutService, OrderRepository orderRepo) {
    this.paymentService = paymentService;
    this.checkoutService = checkoutService;
    this.orderRepo = orderRepo;
  }

  @PostMapping("/verify")
  public ApiResponse<String> verify(@RequestBody PaymentVerificationRequest body) {
    boolean ok = paymentService.verifySignature(
        body.getRazorpayOrderId(),
        body.getRazorpayPaymentId(),
        body.getRazorpaySignature()
    );

    if (!ok) return new ApiResponse<>(false, null, "Signature mismatch");

    Order order = orderRepo.findById(body.getOrderId()).orElse(null);
    if (order == null) return new ApiResponse<>(false, null, "Order not found");
    if (!order.getRazorpayOrderId().equals(body.getRazorpayOrderId()))
      return new ApiResponse<>(false, null, "Order mismatch");

    checkoutService.markPaid(order.getId(), body.getRazorpayPaymentId());
    return new ApiResponse<>(true, "PAID", "Payment verified & order updated");
  }
}
