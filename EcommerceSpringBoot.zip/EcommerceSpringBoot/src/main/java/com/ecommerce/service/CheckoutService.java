package com.ecommerce.service;

import com.ecommerce.entity.*;
import com.ecommerce.repository.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.http.HttpStatus;

import java.util.ArrayList;
import java.util.List;

@Service
public class CheckoutService {
  private final CartItemRepository cartRepo;
  private final OrderRepository orderRepo;
  private final OrderItemRepository orderItemRepo;
  private final UserRepository userRepo;
  private final ProductRepository productRepo;

  public CheckoutService(CartItemRepository cartRepo,
                         OrderRepository orderRepo,
                         OrderItemRepository orderItemRepo,
                         UserRepository userRepo,
                         ProductRepository productRepo) {
    this.cartRepo = cartRepo;
    this.orderRepo = orderRepo;
    this.orderItemRepo = orderItemRepo;
    this.userRepo = userRepo;
    this.productRepo = productRepo;
  }

  @Transactional
  public Order createOrderFromCart(Long userId, String razorpayOrderId) {
    User user = userRepo.findById(userId).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "User not found"));
    List<CartItem> cart = cartRepo.findByUserId(userId);
    if (cart.isEmpty()) throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Cart is empty");

    // Validate stock first
    for (CartItem ci : cart) {
      if (ci.getQuantity() > ci.getProduct().getStock()) {
        throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Not enough stock for product: " + ci.getProduct().getName());
      }
    }

    Order order = new Order();
    order.setUser(user);
    order.setStatus(Order.Status.CREATED);
    order.setRazorpayOrderId(razorpayOrderId);
    // initialize total, items will be added below
    order = orderRepo.save(order);

    double total = 0.0;
    List<OrderItem> itemsToSave = new ArrayList<>();
    for (CartItem ci : cart) {
      OrderItem oi = new OrderItem();
      oi.setOrder(order);
      oi.setProduct(ci.getProduct());
      oi.setQuantity(ci.getQuantity());
      oi.setPrice(ci.getProduct().getPrice());
      total += oi.getPrice() * oi.getQuantity();
      itemsToSave.add(oi);

      // reduce stock
      Product p = ci.getProduct();
      p.setStock(p.getStock() - ci.getQuantity());
      productRepo.save(p);
    }
    order.setTotalAmount(total);
    orderRepo.save(order);
    orderItemRepo.saveAll(itemsToSave);

    cartRepo.deleteByUserId(userId);
    return order;
  }

  @Transactional
  public Order markPaid(Long orderId, String razorpayPaymentId) {
    Order order = orderRepo.findById(orderId).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Order not found"));
    if (order.getStatus() == Order.Status.PAID) {
      return order;
    }
    order.setStatus(Order.Status.PAID);
    order.setRazorpayPaymentId(razorpayPaymentId);
    return orderRepo.save(order);
  }
}
