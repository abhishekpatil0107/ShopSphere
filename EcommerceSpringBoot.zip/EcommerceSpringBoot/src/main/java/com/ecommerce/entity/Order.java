package com.ecommerce.entity;

import jakarta.persistence.*;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "orders")
public class Order {
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  @ManyToOne(optional = false)
  @JoinColumn(name = "user_id")
  private User user;

  private double totalAmount;

  @Enumerated(EnumType.STRING)
  private Status status = Status.CREATED;

  private String razorpayOrderId;
  private String razorpayPaymentId;

  private Instant createdAt = Instant.now();

  @OneToMany(mappedBy = "order", cascade = CascadeType.ALL, orphanRemoval = true)
  private List<OrderItem> items = new ArrayList<>();

  public Order() {}

  public Order(Long id, User user, double totalAmount, Status status, String razorpayOrderId, String razorpayPaymentId, Instant createdAt, List<OrderItem> items) {
    this.id = id;
    this.user = user;
    this.totalAmount = totalAmount;
    this.status = status;
    this.razorpayOrderId = razorpayOrderId;
    this.razorpayPaymentId = razorpayPaymentId;
    this.createdAt = createdAt;
    this.items = items == null ? new ArrayList<>() : items;
  }

  public enum Status { CREATED, PAID, FAILED, CANCELLED }

  public Long getId() { return id; }
  public void setId(Long id) { this.id = id; }

  public User getUser() { return user; }
  public void setUser(User user) { this.user = user; }

  public double getTotalAmount() { return totalAmount; }
  public void setTotalAmount(double totalAmount) { this.totalAmount = totalAmount; }

  public Status getStatus() { return status; }
  public void setStatus(Status status) { this.status = status; }

  public String getRazorpayOrderId() { return razorpayOrderId; }
  public void setRazorpayOrderId(String razorpayOrderId) { this.razorpayOrderId = razorpayOrderId; }

  public String getRazorpayPaymentId() { return razorpayPaymentId; }
  public void setRazorpayPaymentId(String razorpayPaymentId) { this.razorpayPaymentId = razorpayPaymentId; }

  public Instant getCreatedAt() { return createdAt; }
  public void setCreatedAt(Instant createdAt) { this.createdAt = createdAt; }

  public List<OrderItem> getItems() { return items; }
  public void setItems(List<OrderItem> items) { this.items = items; }
}
