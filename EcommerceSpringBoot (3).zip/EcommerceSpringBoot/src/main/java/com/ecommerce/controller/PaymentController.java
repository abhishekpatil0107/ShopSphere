package com.ecommerce.controller;

import com.ecommerce.dto.ApiResponse;
import com.ecommerce.dto.PaymentVerificationRequest;
import com.ecommerce.entity.Order;
import com.ecommerce.service.CheckoutService;
import com.ecommerce.service.PaymentService;
import org.springframework.web.bind.annotation.*;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

@RestController
@RequestMapping("/api/payment")
@CrossOrigin(origins = "http://localhost:3000", allowCredentials = "true")
public class PaymentController {

    private final PaymentService paymentService;
    private final CheckoutService checkoutService;

    public PaymentController(PaymentService paymentService,
                             CheckoutService checkoutService) {
        this.paymentService = paymentService;
        this.checkoutService = checkoutService;
    }

    // Step 1: Create Order (without Razorpay) - useful for Cash on Delivery / testing
    @PostMapping("/create")
    public ApiResponse<Order> createOrder(HttpServletRequest request) {
        Long uid = extractUserId(request);
        if (uid == null) return new ApiResponse<>(false, null, "Login required");

        try {
            Order order = checkoutService.createOrderFromCart(uid);
            return new ApiResponse<>(true, order, "Order created successfully");
        } catch (RuntimeException e) {
            return new ApiResponse<>(false, null, e.getMessage());
        }
    }

    // Step 2: Verify Payment
    @PostMapping("/verify")
    public ApiResponse<Order> verify(@RequestBody PaymentVerificationRequest body) {
        boolean ok = paymentService.verifySignature(
                body.getRazorpayOrderId(),
                body.getRazorpayPaymentId(),
                body.getRazorpaySignature()
        );

        if (!ok) return new ApiResponse<>(false, null, "Signature mismatch");

        // ✅ mark order paid and return updated entity
        Order updatedOrder = checkoutService.markPaid(body.getOrderId(), body.getRazorpayPaymentId());
        return new ApiResponse<>(true, updatedOrder, "Payment verified & order updated");
    }

    private Long extractUserId(HttpServletRequest request) {
        HttpSession s = request.getSession(false);
        if (s != null) {
            Object uidAttr = s.getAttribute("userId");
            if (uidAttr instanceof Long) return (Long) uidAttr;
        }
        String header = request.getHeader("X-USER-ID");
        if (header != null) return Long.valueOf(header);
        return null;
    }
}
