package com.ecommerce.controller;

import com.ecommerce.dto.ApiResponse;
import com.ecommerce.entity.Order;
import com.ecommerce.repository.OrderRepository;
import com.ecommerce.service.CheckoutService;
import com.ecommerce.service.PaymentService;
import org.springframework.web.bind.annotation.*;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/checkout")
@CrossOrigin(origins = "http://localhost:3000", allowCredentials = "true")
public class CheckoutController {

    private final CheckoutService checkoutService;
    private final PaymentService paymentService;
    private final OrderRepository orderRepo;

    public CheckoutController(CheckoutService checkoutService,
                              PaymentService paymentService,
                              OrderRepository orderRepo) {
        this.checkoutService = checkoutService;
        this.paymentService = paymentService;
        this.orderRepo = orderRepo;
    }

    @PostMapping("/create-order")
    public ApiResponse<Map<String, Object>> createOrder(HttpServletRequest request) {
        Long uid = extractUserId(request);
        if (uid == null) return new ApiResponse<>(false, null, "Login required");

        try {
            // 1️⃣ Create local order first (without Razorpay id)
            Order localOrder = checkoutService.createOrderFromCart(uid);

            // Validate total
            if (localOrder.getTotal() <= 0) {
                return new ApiResponse<>(false, null, "Order total invalid");
            }

            // 2️⃣ Create Razorpay order using total amount from local order
            int amountRupees = (int) Math.round(localOrder.getTotal());
            String rpOrderJson = paymentService.createRazorpayOrder(amountRupees);

            // 3️⃣ Parse response and attach to local order
            org.json.JSONObject rp = new org.json.JSONObject(rpOrderJson);
            localOrder.setRazorpayOrderId(rp.getString("id"));
            orderRepo.save(localOrder);

            // 4️⃣ Build response map
            Map<String, Object> resp = new HashMap<>();
            resp.put("id", rp.getString("id")); // Razorpay order id
            resp.put("amount", rp.getInt("amount")); // in paise
            resp.put("currency", rp.getString("currency"));
            resp.put("localOrderId", localOrder.getId());

            return new ApiResponse<>(true, resp, "Razorpay order created successfully");
        } catch (Exception e) {
            // Log full exception for debugging
            e.printStackTrace();
            return new ApiResponse<>(false, null, "Failed to create order: " + e.getMessage());
        }
    }

    @GetMapping("/my-orders")
    public List<Order> myOrders(HttpServletRequest request) {
        Long uid = extractUserId(request);
        return orderRepo.findByUserId(uid);
    }

    private Long extractUserId(HttpServletRequest request) {
        HttpSession s = request.getSession(false);
        if (s != null) {
            Object uidAttr = s.getAttribute("userId");
            if (uidAttr instanceof Long) return (Long) uidAttr;
        }
        String header = request.getHeader("X-USER-ID");
        if (header != null) return Long.valueOf(header);
        return null;
    }
}
